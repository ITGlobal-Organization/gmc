<section class="contact-form-sec">
      <div class="container">
         <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
               <div class="contact-form-content">
                  <h2><span>How Can We</span> Help You?</h2>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
               </div>
               <div class="contact-form-fields">
                  <form>
                     <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-12">
                           <div class="field-inner-con">
                           <input type="text" placeholder="Name" class="form-control">
                        </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-12">
                           <div class="field-inner-con">
                           <input type="number" placeholder="Phone" class="form-control">
                        </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-12">
                           <div class="field-inner-con">
                           <input type="email" placeholder="Email" class="form-control">
                        </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                           <div class="field-inner-con">
                           <input type="text" placeholder="Subject" class="form-control">
                        </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                           <div class="field-inner-con">
                              <select class="form-control">
                                 <option disabled selected>Select Service</option>
                                 <option>Polishing/Paint Correction</option>
                                 <option>Ceramic Coating Paint</option>
                                 <option>Glass Ceramic Coating</option>
                                 <option>Wheel Ceramic Coating</option>
                                 <option>Interior Ceramic Coating</option>
                                 <option>Paint Protection Film</option>
                              </select>
                           </div>
                        </div>
                         <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                           <div class="field-inner-con">
                           <textarea cols="8" rows="8" class="form-control" placeholder="How can we help you? Feel free to get in touch!"></textarea>
                        </div>
                        </div>
                     </div>
                     <div class="con-submit-btn">
                        <button type="submit" class="btn btn-primary">Submit</button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </section>