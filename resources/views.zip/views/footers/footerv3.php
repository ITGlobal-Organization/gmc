<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 padding">
<div class="ft-line"></div>

<div class="middle">

<!--Start Custom Patches-->
<div class="col-xs-12 col-sm-3 col-md-3 col-lg-3 margin-bot10 border">
<div class="ft-heading">Custom Patches</div>

<div id="list4">
    <ul>
      <li><a href="#">Chenille</a></li>
      <li><a href="#">PVC Rubber</a></li>
      <li><a href="#">Leather</a></li>
      <li><a href="#">Sublimated</a></li>
      <li><a href="#">Woven</a></li>
	  <li><a href="#">Sequin</a></li>
	  <li><a href="#">Beaded</a></li> 
    </ul>
    <div class="clr"></div>
</div>	
	
	
<div class="clr"></div>	
</div>
<!--End Custom Patches-->	
	
	
<!--Start Custom Products-->
<div class="col-xs-12 col-sm-3 col-md-3 col-lg-3 margin-bot10 border">
<div class="ft-heading">Custom Products</div>

<div id="list4">
    <ul>
      <li><a href="#">Pins</a></li>
      <li><a href="#">Challenge Coins</a></li>
      <li><a href="#">Keychains</a></li>
      <li><a href="#">Spin Coin</a></li>
      <li><a href="#">Bottle Opener</a></li>
	  <li><a href="#">Socks</a></li>
    </ul>
    <div class="clr"></div>
</div>	
	
	
<div class="clr"></div>	
</div>
<!--End Custom Products-->	
	

<!--Start Assets-->
<div class="col-xs-12 col-sm-3 col-md-3 col-lg-3 margin-bot10 border">
<div class="ft-heading">Assets</div>

<div id="list4">
    <ul>
      <li><a href="#">Thread Charts</a></li>
      <li><a href="#">Iron On Instruction</a></li>
      <li><a href="#">Patch Shapes</a></li>
      <li><a href="#">Backing Guide</a></li>
      <li><a href="#">Woven vs Embroidery</a></li>
	  <li><a href="#">Size Guide</a></li>
    </ul>
    <div class="clr"></div>
</div>	
	
	
<div class="clr"></div>	
</div>
<!--End Assets-->		
	
	
<!--Start Assets-->
<div class="col-xs-12 col-sm-3 col-md-3 col-lg-3 margin-bot10 border text-center">
<img src="images/logo.png" alt=""/>
	
<p class="p">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy</p>

	
<span class="social-media"> 
<a href="#">
<i class="fab fa-facebook-f"></i>
<span class="sr-only">Facebook</span></a>
</span>	
	
<span class="social-media"> 
<a href="#">
<i class="fab fa-twitter"></i>
<span class="sr-only">Twitter</span></a>
</span>
	
	
<span class="social-media"> 
<a href="#">
<i class="fab fa-linkedin-in"></i>
<span class="sr-only">Linkedin</span></a>
</span>

<span class="social-media"> 
<a href="#">
<i class="fab fa-instagram"></i>
<span class="sr-only">Instagram</span></a>
</span>
	
	
	
<div class="clr"></div>	
</div>
<!--End Assets-->	
	
	

	
	
	<div class="clr"></div>
</div>
	
<div class="ft-copy">
2023 © All rights reserved.
</div>

<div class="clr"></div>
</div>