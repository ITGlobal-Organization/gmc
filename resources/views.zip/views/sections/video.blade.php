<div class="popup-img wow fadeInLeft" data-wow-duration="0.9s" data-wow-delay="0.9s">
               <img src="{{ isset($image)?$image:'/images/image-not-found.png'}}" alt="image" class="img-fluid">
               <div class="img-popup-btn">
                  <a href="{{ isset($video)?$video:'javascript:void(0)' }}" target="_blank"><i class="fa fa-play" aria-hidden="true"></i></a>
               </div>
</div>