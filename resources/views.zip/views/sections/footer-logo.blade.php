<div class="footer-content">
              <a href="{{ route('home') }}"><img src="{{ asset(config('site_config.assets.images').'footer-logo.png') }}" alt="image" class="img-fluid"></a>
              <p>{{ __('messages.footer.description')}}</p>
            </div>