<section class="banner-video-wrp">
    <div class="bg-video-wrap">
      <div class="full-screen-banner">
        <h1 class="wow fadeInLeft" data-wow-duration="0.8s" data-wow-delay="0.8s">ABOUT US <span>Leading Real Estate Marketing Agency In Pakistan</span></h1>
        <a href="javascript:void(0)" class="btn btn-primary wow fadeInDown" data-wow-duration="0.9s" data-wow-delay="0.9s">BOOK NOW</a>
      </div>
    </div>
  </section>