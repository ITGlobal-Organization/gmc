<section class="instagram-feed-sec">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="instagram-heading">
              <h2 class="wow fadeInLeft" data-wow-duration="0.8s" data-wow-delay="0.8s">{{ trans('lang.instagram_feeds')}}</h2>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-4 col-md-4 col-sm-4 col-12">
            <div class="feed-imgs wow fadeInDown" data-wow-duration="0.8s" data-wow-delay="0.8s">
              <a href="https://www.instagram.com/calgarypaintingcrew/?igshid=ZmVmZTY5ZGE%3D" target="_blank"><img src="{{ asset(config('site_config.assets.images').'ins1.png') }}" alt="image" class="img-fluid"></a>
            </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-4 col-12">
            <div class="feed-imgs wow fadeInUp" data-wow-duration="1s" data-wow-delay="1s">
              <a href="https://www.instagram.com/calgarypaintingcrew/?igshid=ZmVmZTY5ZGE%3D" target="_blank"><img src="{{ asset(config('site_config.assets.images').'ins2.png') }}" alt="image" class="img-fluid"></a>
            </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-4 col-12">
            <div class="feed-imgs wow fadeInRight" data-wow-duration="1.2s" data-wow-delay="1.2s">
              <a href="https://www.instagram.com/calgarypaintingcrew/?igshid=ZmVmZTY5ZGE%3D" target="_blank"><img src="{{ asset(config('site_config.assets.images').'ins3.png') }}" alt="image" class="img-fluid"></a>
            </div>
          </div>
        </div>
        <div class="banner-btn view-all-btn">
          <a href="https://www.instagram.com/calgarypaintingcrew/?igshid=ZmVmZTY5ZGE%3D" target="_blank" class="btn btn-primary wow fadeInDown" data-wow-duration="1.4s" data-wow-delay="1.4s">{{ trans('lang.view_all') }}</a>
        </div>
      </div>
    </section>