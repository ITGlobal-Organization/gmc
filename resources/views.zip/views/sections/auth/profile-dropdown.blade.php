<div class="block">
    <div class="dropdown-head">
      <button onclick="myFunction()" class="dropbtn-head">{{ $User->name }} &nbsp;<i class="fas fa-caret-down" style="color: #BC13FE;"></i></button>
      <div id="myDropdown" class="dropdownhead-contenthead">
        <a href="##">{{ trans('lang.log-out') }}</a>
      </div>
    </div>	
  </div>
  <div class="icon-genral none">
    <a href="#" title="Login"><i class="far fa-sign-in" style="color: #ffffff;"></i></a>
  </div>