<div class="login-btn block"><a href="{{ route('login') }}">{{ trans('lang.login') }}</a></div>
<div class="icon-genral none">
   <a href="{{ route('login') }}" title="{{ trans('lang.login') }}"><i class="far fa-sign-in" style="color: #ffffff;"></i></a>
</div>