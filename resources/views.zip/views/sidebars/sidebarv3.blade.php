
<div class="text-right menu-set">
<div id="mySidenav" class="sidenav"> <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

<div id="list7">
    <ul>
      <li>
	  <a href="#"><img src="images/new-order.png" alt=""/ width="20">&nbsp;&nbsp;New Order</a>
	</li>
      <li>
		  <a href="#"><img src="images/new-quote.png" alt=""/ width="20">&nbsp;&nbsp;New Quote</a>
		</li>
      <li>
		 <a href="#"><img src="images/order-history.png" alt=""/ width="20">&nbsp;&nbsp;Order History</a>
		</li>
      <li>
		<a href="#"><img src="images/quote-history.png" alt=""/ width="20">&nbsp;&nbsp;Quote History</a>
		</li>
      <li>
		 <a href="#"><img src="images/order-track.png" alt=""/ width="20">&nbsp;&nbsp;Order Track</a>
		</li>
	  <li>
		 <a href="#"><img src="images/invoices.png" alt=""/ width="20">&nbsp;&nbsp;Invoices</a>
		</li>
	 <li>
		 <a href="#"><img src="images/profile.png" alt=""/ width="20">&nbsp;&nbsp;Profile</a>
		</li>
    </ul>
    <div class="clr"></div>
</div>




</div>
<span class="menu-mobile" onclick="openNav()">&#9776;</span>
</div>

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "320px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
