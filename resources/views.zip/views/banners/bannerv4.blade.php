<section class="blogs-sec-bg" style="background-image: url(../images/blog-banner.png);">
      <div class="blogs-banner-overlay"></div>
      <div class="container">
         <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
               <div class="banner-inner-content">
                  <h1>{!! $heading !!}</h1>
                  <p>{!! $subheading !!}</p>
               </div>
            </div>
         </div>
      </div>
</section>