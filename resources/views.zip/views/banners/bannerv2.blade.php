<section class="about-banner-sec">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="about-banner-content">
              <h2>{{ trans('lang.about_us') }}</h2>
            </div>
          </div>
        </div>
      </div>
    </section>